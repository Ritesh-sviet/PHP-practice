<?php
echo <<< END

<style>
*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
header{
    border: 3px solid gray;
    width: 100%;
    float: left;
}
section{
    max-width: 600px;
    margin: 0 auto;
}

.btn{
    width: 100%;
}

.title h1{
    width: 100%;
    text-align: center;
}

.register{
    max-width: 200px;
    margin: 0 auto;

}
.copyright{
    max-width: 600px;
    margin: 0 auto;
    margin-top: 20px;
}
.copyright h3{
    text-align: center;
}
#tc{
    display: flex;
    gap:5px;

}
</style>

END;
?>