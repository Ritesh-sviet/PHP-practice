// var config = {

//   cUrl: 'https://api.countrystatecity.in/v1/countries', //here the api is called

//   cKey: 'M0ZBanFTSzVBQllDalE5UUtKWXR4ZzZoU1VWRFh5MHNETWdmVzlVeQ==' //here is the api key 
// }

// var countrySelect = document.querySelector(".country"); //here we select the class of country
// var StateSelect = document.querySelector(".state"); // same the class for states 
// var CitySelect = document.querySelector(".city"); // same for city



// This function is used to load all the countries in the console
// then the API is linked with the help of the config object that is created above
/* then we fetch the data from API and from the header key given to the website and assign
the API key to the header and store the Response to a new file named Response.json*/

// -- created by Ritesh Sharma


// function LoadCounrty() {
//   let apiEndPoint = config.cUrl;
//   fetch(apiEndPoint, { headers: { "X-CSCAPI-KEY": config.cKey } }).then(Response => Response.json()).then(data => {
//     // console.log(data);

//     data.forEach(country => {

//       const option = document.createElement('option');
//       option.value = country.iso2;
//       option.textContent = country.name;
//       countrySelect.appendChild(option);

//     });
//   })
//     .catch(error => console.error('Error Loading in Countries: ', error));
// }

// function loadStates() {
//   const selectedCountryCode = countrySelect.value;
//   // console.log(selectedCountryCode);



//   StateSelect.innerHTML = '<option value="">Select State</option>';

//   fetch(`${config.cUrl}/${selectedCountryCode}/states`, { headers: { "X-CSCAPI-KEY": config.cKey } }).then(response => response.json()).then(data => {
//     // console.log(data);

//     data.forEach(state => {
//       const option = document.createElement('option')
//       option.value = state.iso2
//       option.textContent = state.name
//       StateSelect.appendChild(option)
//     })
//   })
//     .catch(error => console.error('Error Loading in States: ', error));
// }

// function loadCity() {
//   const selectedCountryCode = countrySelect.value;
//   const selectedStateCode = StateSelect.value;

//   CitySelect.innerHTML = '<option value="">Select City</option>';

//   fetch(`${config.cUrl}/${selectedCountryCode}/states/${selectedStateCode}/cities`, { headers: { "X-CSCAPI-KEY": config.cKey } }).then(response => response.json()).then(data => {
//     data.forEach(city => {
//       const option = document.createElement('option');
//       option.value = city.iso2;
//       option.textContent = city.name;
//       CitySelect.appendChild(option);
//     })
//   })
//     .catch(error => console.error('Error Loading in States: ', error));
// }



// window.onload = LoadCounrty();
// window.onload = loadStates();
// window.onload = loadCity();


function validateForm() {
  let x = document.forms["myform"]["fname"].value;
  if (x == "") {
    alert("first name must be filled out");
    return false;
  }
  let y = document.forms["myform"]["lname"].value;
  if (y == "") {
    alert("last name must be filled out");
    return false;
  }
  let z = document.forms["myform"]["DOB"].value;
  if (z == "") {
    alert("Date of Birth must be filled out");
    return false;
  }
  let a = document.forms["myform"]["email"].value;
  if (a == "") {
    alert("email must be filled out");
    return false;
  }
  let ab = document.forms["myform"]["phone"].value;
  if (ab == "") {
    alert("Mobile Number must be filled out");
    return false;
  }
  let b = document.forms["myform"]["phone"].value;
  if (b == "") {
    alert("phone must be filled out");
    return false;
  }
  let c = document.forms["myform"]["gridRadios"].value;
  if (c == "") {
    alert("Gender must be filled out");
    return false;
  }
  let d = document.forms["myform"]["department"].value;
  if (d == "") {
    alert("department must be filled out");
    return false;
  }

  let e = document.forms["myform"]["username"].value;
  if (e == "") {
    alert("username must be filled out");
    return false;
  }

  let password = document.forms["myform"]["password"].value;
  if (password == "") {
    alert("password must be filled out");
    return false;
  }
  let confirm = document.forms["myform"]["confirm"].value;
  if (confirm == "") {
    alert("repeat password must be filled out");
    return false;
  }

  if(password !="" && confirm != "" && password != confirm)
  {
    alert("password does not matched with confirm password field");
    return false;
  }

  let h = document.forms["myform"]["profile"].value;
  if (h == "") {
    alert("profile must be filled out");
    return false;
  }
  let checkbox = document.form["myform"]["terms"].checked;
  console.log(checkbox);
  if (!checkbox){
    alert("please accept terms and conditions");
    return false;
  }
  let j = document.forms["myform"]["country"].value;
  if (j == "") {
    alert("country must be filled out");
    return false;
  }
  let k = document.forms["myform"]["state"].value;
  if (k == "") {
    alert("state must be filled out");
    return false;
  }

  let l = document.forms["myform"]["city"].value;
  if (l == "") {
    alert("city must be filled out");
    return false;
  }
  let m = document.forms["myform"]["pincode"].value;
  if (m == "") {
    alert("pincode must be filled out");
    return false;
  }
  let n = document.forms["myform"]["District"].value;
  if (n == "") {
    alert("District must be filled out");
    return false;
  }
  let o = document.forms["myform"]["full-address"].value;
  if (o == "") {
    alert("fulladdress must be filled out");
    return false;
  }
}

