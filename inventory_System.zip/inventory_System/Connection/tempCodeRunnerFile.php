<?php
$query = "select name, id from states where countryid = 3";
$result = mysqli_query($conn, $query) or die("Query not found");
print_r(mysqli_fetch_assoc($result));